<?php

namespace App\Services\Gateway;

class THeadPaySDK {
    public function __construct($config) {
        $this->config = $config;
    }

    public function pay($order) {
        $params = [
            'pid' => $this->config['theadpay_mchid'],
            'out_trade_no' => $order['trade_no'],
            'money' => (string)$order['total_fee'], // in cents
			'name' => (string)$order['total_no'],
            'notify_url' => $order['notify_url'],
            'return_url' => $order['return_url'],
        ];
        $params['sign'] = $this->sign($params);
		$params['sign_type'] = 'MD5';
        $data = http_build_query($params);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->config['theadpay_url'] . "/mapi.php?" . $data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        $data = curl_exec($curl);
        curl_close($curl);

        $result = json_decode($data, true);
        if (!is_array($result) || !isset($result["code"])) {
            throw new \Exception('网络连接异常: 无法连接支付网关');
        }
        if ($result["code"] != "1") {
            throw new \Exception($result["message"]);
        }

        return $result;
    }

    public function verify($params) {
        return $params['sign'] === $this->sign($params);
    }

    protected function sign($params) {
		$para_filter = array();
		foreach ($params as $key=>$val) {
			if($key == "sign" || $key == "sign_type" || $val == "")continue;
			else $para_filter[$key] = $para[$key];
		}
        unset($para_filter['sign']);
        ksort($para_filter);
        reset($para_filter);
		$arg  = "";
		foreach ($para_filter as $key=>$val) {
			$arg.=$key."=".$val."&";
		}
		//去掉最后一个&字符
		$arg = substr($arg,0,-1);
        $data = $arg . $this->config['theadpay_key'];
        return md5($data);
    }
}